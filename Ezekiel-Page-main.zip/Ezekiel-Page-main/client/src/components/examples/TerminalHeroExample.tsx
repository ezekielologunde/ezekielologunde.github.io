import TerminalHero from '../TerminalHero';

export default function TerminalHeroExample() {
  return <TerminalHero />;
}
