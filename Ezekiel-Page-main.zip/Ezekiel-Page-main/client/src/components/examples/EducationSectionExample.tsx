import EducationSection from '../EducationSection';

export default function EducationSectionExample() {
  return <EducationSection />;
}
